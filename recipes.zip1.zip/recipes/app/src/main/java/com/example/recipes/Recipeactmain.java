package com.example.recipes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class Recipeactmain extends AppCompatActivity {

    RecyclerView mRecyclerView;
    List<FoodData> myFoodList;
    FoodData mFoodData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipeactmain);

        mRecyclerView=(RecyclerView)findViewById(R.id.recyclerView);

        GridLayoutManager gridLayoutManager=new GridLayoutManager(Recipeactmain.this,1);
        mRecyclerView.setLayoutManager(gridLayoutManager);

        myFoodList=new ArrayList<>();

        mFoodData=new FoodData("DOSA","\n"+"Recipe:\n 1.Prepare Dosa Batter:Soak rice and urad dal in separate bowls for 4-6 hours. Strain.\n" +
                "2.Process rice and urad dal mixture in commercial grinder or food processor. While grinding, add water a cup at a time until it reaches the consistency of pancake batter.\n" +
                "3.Salt to taste.\n" +
                "4.Cover mixture and let sit overnight. Do not refrigerate; it needs to ferment.\n" +
                "5.Prepare Masala Dosa Filling: Add oil or ghee to a skillet.\n" +
                "6.Add mustard seeds and chana dal.\n" +
                "7.Shake mixture over the flame until golden brown.\n" +
                "8.Add curry leaves (whole leaf), green chiles, and onions.\n" +
                "9.Sprinkle turmeric powder and salt (for taste). Stir.\n" +
                "10.Break up boiled potato into small chunks and add them to your mixture. Add water and stir.\n" +
                "11.Prepare Masala Dosa: Pour refrigerated dosa mixture into a small bowl with a flat bottom.\n" +
                "12.Pour batter into a greased skillet.\n" +
                "13.Immediately, starting from the center, begin forming a circular shape with the batter using the flat-bottomed dish.\n" +
                "14.Brush on ghee (or regular butter) to frying dosa.\n" +
                "15.Place filling near the center of the dosa.\n" +
                "16.Lightly lift the edges of the dosa.\n" +
                "17.Begin rolling from the edge of the dosa as you would a wrap.\n" +
                "18.Remove dosa from hot top or skillet.\n" +
                "19.Masala Dosa is typically served with coconut, cilantro and tomato chutney as well as sambar (vegetable lentil stew)",R.drawable.dosaa);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("JELEBI","\n"+"Recipe:\n 1.In a mixing bowl, mix maida, corn flour, curd.\n" +
                "2.Then add half tsp vinegar and water.\n" +
                "3.Mix well in round circular directions for 4 minutes.\n" +
                "4.Now add baking soda and give a gentle mix.\n" +
                "5.Now pour this batter in the tomato ketchup bottles carefully.\n" +
                "6.Heat oil in a pan and add 1 tbsp of ghee.\n" +
                "7.Squeeze the bottle and make round spirals with the batter.\n" +
                "8.When one side is partly cooked, turn over and fry the other side.\n" +
                "9.Fry till the jalebis are a light golden.\n" +
                "10.Then immediately drop the fried jalebis in the warm sugar syrup for 30 seconds (1 string consistency).\n" +
                "11.Finally, serve jalebis hot, warm or at room temperature.",R.drawable.jelebi);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("SAMOSA","\n"+"Recipe:\n 1.Mix flour, water, oil, salt and red chilli powder to make dough.\n" +
                "2.It should not be very soft. Leave aside for 15 minutes.\n" +
                "3.Heat two tsp oil and add potatoes and peas. Cover on low flame for 5 minutes.\n" +
                "4.Add garam masala, pepper, amchur and jeera powder, mix well and again cover for 5-8 minutes.\n" +
                "5.Add cashew nuts and resins in the end and keep on flame for 3-5 minutes.\n" +
                "6.Keep aside to cool.\n" +
                "7.Roll small balls of the dough like chapati.\n" +
                "8.Cut each in two parts (like semi-circle), then take one semi circle and fold it in the shape of a cone. Use water while doing so.\n" +
                "9.Stuff the mixture of potatoes, peas and spices in that cone and seal it by taking a drop of water on your finger.\n" +
                "10.Heat oil and fry.\n" +
                "11.Serve hot with tamarind chutney or green chutney.",R.drawable.samosa);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("PAV BHAJI","\n"+"Recipe:\n1.To prepare the pav bhaji, start by prepping the vegetables. Peel the potato and carrot. Wash the cauliflower florets well.\n" +
                "2.Slice up the potatoes and carrot. (if you have access to frozen chopped vegetables, use them here to speed up the process)\n" +
                "3.In a pressure pan, place sliced potatoes, carrots, cauliflower florets, frozen peas and garlic cloves. Add 1/2 tsp salt and 1 cup water. Pressure cook for 2 whistles and keep on sim for 5-6 minutes. Once you are able to open the cooker, open the lid and using a wooden masher or a potato masher, mash the cooked veggies to get a coarse puree.\n" +
                "4.While the vegetables cook, using a food processor or a chopping board and knife, chop the onion and bell pepper finely.\n" +
                "5.Heat the oil in a heavy bottomed pan. Add the finely chopped onion and bell pepper, and saute on medium flame until they are softened, around 5 minutes.\n" +
                "6.To this, add the red chilli powder, pav bhaji masala and stir on low flame for 30 seconds.\n" +
                "7.Add the tomato puree, 1/2 - 3/4tsp salt and bring to a simmer.\n" +
                "8.Add the mashed vegetables to this and thin with a a few spoons of water if required. Allow this to simmer for 3-4 minutes.\n" +
                "9.Remove from flame, garnish with coriander and lemon wedges and serve with buttered and toasted pav.",R.drawable.pavbhaji);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("PIZZA","\n"+"Recipe:\n 1.In large bowl, mix first 4 ingredients.\n" +
                "2.Mix water and oil; add to flour mixture.\n" +
                "3.Turn onto floured surface; knead for 2 minutes.\n" +
                "4.Place in a greased bowl; turning to grease top.\n" +
                "5.Cover and let rise for 20 minutes.\n" +
                "6.Punch down; place on 12in, greased pizza pan.\n" +
                "7.Pat into a circle.\n" +
                "8.Topping: Mix first 5 ingredients and spread over crust.\n" +
                "9.Put a few pepperoni slices on top of sauce.\n" +
                "10.Sprinkle with 1/2 the mozzeralla; 1/2 the monterey jack, and 1/2 the parmesan.\n" +
                "11.Put the rest of the pepperoni on.\n" +
                "12.Repeat the cheese layer.\n" +
                "13.Bake at 400* for 20 minutes or until light brown.",R.drawable.pizza);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("PASTA","\n"+"Recipe:\nPrepare sauce \n1.Cook the tomatoes in a pan.\n" +
                "2.Add the clove of garlic, onion and bay leaf to it.\n" +
                "3.Add water and then season with salt and sugar.\n" +
                "4.Cover and let the tomatoes boil.\n" +
                "5.Cool and then grind to a puree.\n" +
                "6.Now in a separate pan, heat oil and add chopped onions and chopped garlic.\n" +
                "7.Add the tomato puree. Cook till its reduces to half.\n" +
                "8.Add basil leaves and keep aside.\n" +
                "Prepare Pasta:\n" +
                "1.Boil water with salt.\n" +
                "2.Add the pasta to it and let it boil. Drain when done\n" +
                "3.Transfer in a serving dish and serve with the tomato sauce.",R.drawable.pasta);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("LASAGNA","\n"+"Recipe:\n 1.Heat the oven to 400°. Peel and finely chop the garlic. Cook the beef and garlic in the skillet over medium heat about 5 minutes, stirring occasionally, until the beef is brown; drain.\n" +
                "2.Stir the Italian seasoning and spaghetti sauce into the beef. Spread 1/4 cup of the beef mixture in the ungreased square pan.\n" +
                "3.Top with 2 noodles, placing them so they do not overlap or touch the sides of the pan because they will expand as they bake. Spread about 1/2 cup of the remaining beef mixture over the noodles.\n" +
                "4.Spread about 1/2 cup of the cottage cheese over the beef mixture. Sprinkle with about 1/3 cup of the mozzarella cheese.\n" +
                "5.Repeat layering twice more, beginning with 2 more noodles and following directions in steps 3 and 4 Sprinkle with the parmesan cheese.",R.drawable.lasagna);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("RISOTTO","\n"+"Recipe:\n1.Saute onion and mushrooms in oil and butter until soft.\n" +
                "2.Stir in rice and cook till transparent, add wine if it gets dry.\n" +
                "3.stir in 1 ladle of stock. Stir well, cover and simmer gently for several minutes or till rice looks dry.\n" +
                "4.Add more stock, stir,cover and keep repeating this process till rice is just cooked (about 25 minutes).\n" +
                "5.Taste and add a little salt.\n" +
                "6.Now remove from heat and stir in parmesan, parsley, extra butter if using and pepper to taste.",R.drawable.risotto);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("PITA CHIPS","\n"+"Recipe:\n 1.Preheat your oven to 375F and line a baking sheet with aluminum foil or baking mat.\n" +
                "2.Brush both sides of the pita with olive oil and sprinkle some sea salt.\n" +
                "3.Cut the pitas into 8 wedges using a pizza cutter or a sharp knife.\n" +
                "4.Bake in the oven for eight to ten minutes. Flip once so both sides get crispy.",R.drawable.pitachips);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("HUMMUS","\n"+"Recipe:\n1.In a food processor, puree the chickpeas and garlic with the olive oil, lemon juice, tahini (if using), cumin, and ¾ teaspoon salt until smooth and creamy. Add 1 to 2 tablespoons water as necessary to achieve the desired consistency."+
                "2.Transfer to a bowl. Drizzle with olive oil and sprinkle with the paprika before serving.",R.drawable.hummus);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("FALAFEL","\n"+"Recipe:\n 1.Firstly soak 1 cup of chickpea with enough water for overnight.\n" +
                "2.Next day, drain off the water and transfer to a bowl or food processor.\n" +
                "3.Also add in ½ onion, fistful coriander leaves, 2 cloves garlic, ½ tsp coriander powder, ½ tsp cumin powder, ½ tsp chilli powder, ½ tsp pepper, crushed, 1 tbsp lemon juice and salt to taste.\n" +
                "4.Additionally, add in 2 tbsp maida.\n" +
                "5.Blend coarsely in a food processor without adding any water.\n" +
                "6.Add in baking soda and mix well.\n" +
                "7.Now wet your hands and prepare small sized balls. if the dough is sticking to hands then add a tbsp more of maida and mix well.\n" +
                "8.Deep fry the balls in hot oil.\n" +
                "9.Also stir occasionally, keeping the flame on medium.\n" +
                "10.Once the falafel turns golden brown, drain off on to the kitchen paper.\n" +
                "11.Finally, serve falafel hot with hummus or sauce of your choice.",R.drawable.falafel);
        myFoodList.add(mFoodData);

        mFoodData=new FoodData("LEBANESE BAKLAVA","\n"+"Recipe:\n1.Place a layer of phyllo pastry sheets in the bottom of a prepared and greased pan.\n" +
                "2.Add the mixture of crushed walnuts and sugar evenly on top, smoothening out with a spatula.\n" +
                "3.Add the rest of the phyllo sheets carefully on top.\n" +
                "4.Cut into diamonds and pour over the clarified butter. Bake.",R.drawable.baklava);
        myFoodList.add(mFoodData);

        MyAdapter myAdapter=new MyAdapter(Recipeactmain.this,myFoodList);
        mRecyclerView.setAdapter(myAdapter);
    }
}